# CyberSmart Quest — Agilisium Cybersecurity Awareness Challenge

A five-stage cybersecurity awareness game with:

- **Sign-in with full name and employee ID**: IDs are checked against the HR employee list. If the list has a name for that ID, the official name is used; otherwise the name the player types is used.
- **Individual and group play.**
- **Saved results:** every player's points, level history and answers.
- **Shared booth leaderboard and cyber wheel** across all laptops.
- **Password-protected Organiser dashboard** with live statistics and CSV exports.

The game is a single page served by a small Node.js server. There are no npm dependencies and no external database; everything runs in **one Docker container**.

```
agilisium-cyber-challenge/
├── public/index.html          # the game (frontend)
├── server/server.js           # API + static file server (backend)
├── Dockerfile
├── docker-compose.yml         # HTTP on port 80
├── docker-compose.https.yml   # optional HTTPS with Caddy (needs a domain)
├── Caddyfile
├── .env.example               # copy to .env and set your passwords
└── sample/employees.sample.csv
```

## 1. Deploy on AWS EC2

### 1.1 Launch the instance
- **AMI:** Ubuntu 22.04 or 24.04 LTS (or Amazon Linux 2023).
- **Size:** `t3.small` is plenty for hundreds of players (`t3.micro` works for testing).
- **Storage:** 10–20 GB gp3.
- **Security group inbound rules:**
  - TCP **22** (SSH), from your IP only.
  - TCP **80** (HTTP), from `0.0.0.0/0` or your office IP range.
  - TCP **443** (HTTPS), only if you use the HTTPS setup.
- **Elastic IP:** attach one so the address doesn't change on reboot.

### 1.2 Install Docker (Ubuntu)
```bash
sudo apt-get update && sudo apt-get install -y ca-certificates curl git
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER && newgrp docker
docker compose version      # should print v2.x
```

### 1.3 Get the code and configure it
```bash
git clone https://github.com/<your-org>/agilisium-cyber-challenge.git
cd agilisium-cyber-challenge
cp .env.example .env
nano .env                   # set ADMIN_PASSWORD and TOKEN_SECRET
```
Generate a token secret with `openssl rand -hex 32`.

### 1.4 Start it
```bash
docker compose up -d --build
docker compose ps           # STATUS should become "healthy"
docker compose logs -f
```
Open **http://\<EC2-public-IP\>/** in any browser.

### 1.5 Upload the employee list
1. Open **http://\<EC2-public-IP\>/#admin** and enter `ADMIN_PASSWORD`.
2. Click **Employee list** and choose a CSV with the columns `EmployeeID,Name`; see `sample/employees.sample.csv`.

From then on, only IDs in the list can log in, and the player's name is filled in automatically.

Until a list is uploaded, any ID of 3 or more characters is accepted, which is handy for a dry run. Set `ALLOW_UNKNOWN_IDS=true` to always accept unknown IDs.

## 2. Optional: HTTPS with your own domain
1. Point a DNS record (for example `cyberchallenge.agilisium.com`) to the EC2 Elastic IP.
2. Set `DOMAIN=` in `.env`.
3. Open ports 80 and 443 in the security group.
4. Run:
```bash
docker compose -f docker-compose.yml -f docker-compose.https.yml up -d --build
```
Caddy obtains and renews the TLS certificate automatically.

## 3. Running the booth (20 laptops)
- **Browser:** use **Microsoft Edge** or **Chrome** and open the game URL on every laptop. Edge has the best Indian-English female narrator voice.
- **Kiosk mode:** `msedge --kiosk http://<server>/ --edge-kiosk-type=fullscreen`
- **Booth settings:** on each laptop, open **Leaderboard & rewards → Organiser settings** and switch on:
  - **Booth mode**: a "Next player" button plus an automatic reset after inactivity.
  - **Unlock all stages**, if visitors have limited time.
  - **Background music** on one laptop only, or use headphones.
- **Shared leaderboard:** it combines all laptops. Show `/#booth` on a big screen.
- **Wi-Fi drops:** answers stay on the laptop and are sent automatically when the connection returns.
- **Live progress:** keep `/#admin` open on an organiser laptop. It refreshes every 30 seconds.

## 4. Organiser dashboard (`/#admin`)
- **Headline numbers:** registered players, employees covered, groups, completion rate, average points and average final score.
- **How far players got:** each stage and the Final Challenge.
- **Levels and ranks:** level and final-rank distributions.
- **Topic accuracy:** % correct for each topic, plus questions **answered correctly by everyone** and the **most missed**.
- **Players table:** searchable; click a player for their stage scores and full **points & level history**.
- **Downloads:** **Players CSV** and **Questions CSV**.

## 5. Prize rules and organiser controls
- **Only the first attempt counts.** Replays are practice and don't add points or combo bonuses. "Restart my game" creates a *practice run* that isn't eligible for prizes.
- **Eligibility:** individual players who finished all 5 stages and the Final. The first run per employee ID counts.
- **Tiers** (100 prizes, unused slots roll down):

  | Tier | Rule | Slots |
  |---|---|---|
  | 🏆 Champion | Top 3 scores overall (Final completed) | 3 |
  | 💎 Platinum | 1,200+ points, 11+ badges, Final ≥ 90% | 17 |
  | 🥇 Gold | 1,075+ points, 9+ badges, Final ≥ 80% | 30 |
  | 🥈 Silver | 875+ points, 7+ badges, Final ≥ 70% | 50 |

- **Order:** tier first, then points → Final % → badges → shortest active play time → earliest finish.
- **Teams:** a separate top-3 "Best Team" prize.
- **Organiser dashboard:**
  - the **🏆 Prize ranking** tab, with a **Winners CSV** download;
  - **🗑** on any row deletes a trial entry, and can delete all entries for one employee ID;
  - **Delete all** clears every result before the event starts.
- **Player flow:**
  1. Log in, and **How to play** starts automatically with narration, ending with "Let's start!".
  2. Stage 1 opens.
  3. After the Final, a short page shows the player's **live rank**, plus optional bonus points: the **Tip gallery** (+2 per tip) and one **bonus wheel** spin (+10 to +50). Players can **skip** straight to their certificate.
  4. **Finish & see my ranking**, which appears after the spin, locks the score and shows rank, points, active time, first-try correct answers, badges and level.
- **30-minute limit:** the timer starts when *How to play* ends (the narrator says "Your timer starts now"), and it's shown in the top-right corner. It turns orange at 10 minutes left, and at 5 minutes left an alert pops up with narration. At 30:00 the game finishes automatically and opens the Tip gallery, bonus wheel and Finish screen. Timed-out players are ranked on points; prize tiers still need the Final. There's also a **Full screen** button on the sign-in page and in the top bar.
- **Stage map on request:** it appears only when a player opens it from the **Map** button or the ☰ menu.
- **Full ranking:** the dashboard lists every employee. Finishers are ranked, and everyone else is shown under "Not ranked yet". **Full ranking CSV** exports them all.

## 6. Data, backups and updates
Data lives in the Docker volume `cyberdata`, mounted at `/data`. It holds two files:
- `runs.json`: all players' results.
- `employees.csv`: the uploaded employee list.

**Back up:**
```bash
docker compose cp app:/data/runs.json ./backup-runs-$(date +%F).json
```
**Restore:**
```bash
docker compose cp ./backup-runs.json app:/data/runs.json && docker compose restart
```
**Update after a git pull:**
```bash
git pull && docker compose up -d --build
```
Player data is kept, because it lives in the volume rather than the image.

**Stop:**
```bash
docker compose down
```
This keeps the data. `docker compose down -v` deletes all results.

## 7. Configuration (`.env`)
| Variable | Default | Purpose |
|---|---|---|
| `ADMIN_PASSWORD` | required | Password for the organiser dashboard |
| `TOKEN_SECRET` | random at start | Signs organiser sessions; set it so logins survive restarts |
| `ALLOW_UNKNOWN_IDS` | `false` | `true` lets any employee ID log in |
| `ORG_NAME` | `Agilisium` | Shown in server responses and logs |
| `DOMAIN` | — | Only for the HTTPS setup |

## 8. API reference
| Method | Path | Who | Purpose |
|---|---|---|---|
| GET | `/api/health` | anyone | Health check |
| POST | `/api/login` | players | Check an employee ID (or group IDs) and return the name |
| POST | `/api/runs` | players | Save a player's run (sent automatically) |
| POST | `/api/runs/:id/reward` | booth | Cyber-wheel reward (once per run) |
| GET | `/api/leaderboard` | anyone | Top 10 across all laptops |
| POST | `/api/admin/login` | organiser | Returns a 12-hour session token |
| GET | `/api/admin/runs` | organiser | All players' results |
| POST | `/api/admin/employees` | organiser | Upload the employee CSV |
| DELETE | `/api/admin/runs/:id` | organiser | Delete one entry (trial runs) |
| DELETE | `/api/admin/runs` | organiser | Delete all results |
| GET | `/api/rank/:id` | player | Player's live prize rank |

## 9. Privacy
The game stores employee IDs, names (from the uploaded list), scores, badges and answers. No passwords or free text are stored. Inform employees and agree on a retention period with HR.

## Pre-launch checklist
- [ ] `.env` created with a strong `ADMIN_PASSWORD` and a random `TOKEN_SECRET` (`openssl rand -hex 32`).
- [ ] `docker compose up -d --build` → `docker compose ps` shows **healthy**.
- [ ] Open `http://<EC2-IP>/` → sign-in page loads, and the logos and backgrounds are visible.
- [ ] `/#admin` → log in → **Employee list** → upload the HR CSV (`EmployeeID,Name`).
- [ ] Sign in with a test ID → How to play → Stage 1 → play a few questions → check **Players CSV** on the dashboard.
- [ ] Delete the test entries (🗑 or **Delete all**) before opening to everyone.
- [ ] Laptops need internet access for Google Fonts and the **Download certificate (PDF)** button (loaded from cdnjs.cloudflare.com). Everything else is served by the EC2 container.
- [ ] Timers: 30-minute game timer (alert at 5 minutes left). When time is up, players go straight to the Final Challenge (counts for Final score, no points), then the Tip gallery and bonus wheel.
