/*
 * Agilisium Cybersecurity Awareness Challenge — backend
 * Zero-dependency Node.js (v20+) server:
 *   • serves the game (../public)
 *   • employee-ID login checked against data/employees.csv
 *   • saves every player's run (points, level history, answers) to data/runs.json
 *   • shared booth leaderboard
 *   • password-protected organiser API for the dashboard
 */
const http = require("http");
const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");
const crypto = require("crypto");

const PORT = +(process.env.PORT || 8080);
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "..", "data");
const PUBLIC_DIR = process.env.PUBLIC_DIR || path.join(__dirname, "..", "public");
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "";
const TOKEN_SECRET = process.env.TOKEN_SECRET || crypto.randomBytes(32).toString("hex");
const ALLOW_UNKNOWN_IDS = /^(1|true|yes)$/i.test(process.env.ALLOW_UNKNOWN_IDS || "false");
const ORG_NAME = process.env.ORG_NAME || "Agilisium";
const RUNS_FILE = path.join(DATA_DIR, "runs.json");
const EMP_FILE = path.join(DATA_DIR, "employees.csv");
const MAX_BODY = 512 * 1024;

if (!ADMIN_PASSWORD) console.warn("[warn] ADMIN_PASSWORD is not set — the organiser dashboard is disabled until you set it.");
fs.mkdirSync(DATA_DIR, { recursive: true });

/* ---------- storage (JSON file, atomic writes) ---------- */
let runs = {};
try { runs = JSON.parse(fs.readFileSync(RUNS_FILE, "utf8")); } catch { runs = {}; }
let saveTimer = null, saving = false, dirty = false;
function scheduleSave() {
  dirty = true; if (saveTimer) return;
  saveTimer = setTimeout(async () => {
    saveTimer = null; if (saving) { scheduleSave(); return; }
    saving = true; dirty = false;
    const tmp = RUNS_FILE + ".tmp";
    try { await fsp.writeFile(tmp, JSON.stringify(runs)); await fsp.rename(tmp, RUNS_FILE); }
    catch (e) { console.error("[save]", e.message); dirty = true; }
    saving = false; if (dirty) scheduleSave();
  }, 400);
}
function flushSync() { try { fs.writeFileSync(RUNS_FILE, JSON.stringify(runs)); } catch (e) { console.error(e); } }
process.on("SIGTERM", () => { flushSync(); process.exit(0); });
process.on("SIGINT", () => { flushSync(); process.exit(0); });

/* ---------- employee list ---------- */
let employees = new Map();
const cleanId = v => String(v || "").replace(/[^A-Za-z0-9\-_]/g, "").toUpperCase().slice(0, 20);
function parseCSV(text) {
  const rows = []; let row = [], cur = "", q = false;
  text = text.replace(/^\uFEFF/, "");
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"' && text[i + 1] === '"') { cur += '"'; i++; } else if (c === '"') q = false; else cur += c; }
    else if (c === '"') q = true;
    else if (c === ",") { row.push(cur); cur = ""; }
    else if (c === "\n" || c === "\r") { if (c === "\r" && text[i + 1] === "\n") i++; row.push(cur); rows.push(row); row = []; cur = ""; }
    else cur += c;
  }
  if (cur.length || row.length) { row.push(cur); rows.push(row); }
  return rows.filter(r => r.some(x => x.trim()));
}
function loadEmployees(text) {
  const rows = parseCSV(text); const m = new Map();
  if (!rows.length) return m;
  const h = rows[0].map(x => x.trim().toLowerCase());
  let iId = h.findIndex(x => /emp|^id$|code/.test(x)), iName = h.findIndex(x => /name/.test(x));
  let start = 1;
  if (iId < 0) { iId = 0; iName = 1; start = /^[a-z0-9\-_]+$/i.test(rows[0][0] || "") && !/[a-z]{4,}/i.test(rows[0][0]) ? 0 : 1; }
  for (const r of rows.slice(start)) { const id = cleanId(r[iId]); if (id) m.set(id, String(r[iName] || "").trim().slice(0, 60)); }
  return m;
}
try { employees = loadEmployees(fs.readFileSync(EMP_FILE, "utf8")); console.log(`[employees] ${employees.size} loaded`); }
catch { console.log("[employees] no employees.csv yet — " + (ALLOW_UNKNOWN_IDS ? "any ID allowed" : "any ID allowed until you upload one")); }
function lookup(id) {
  id = cleanId(id); if (id.length < 3) return null;
  if (employees.has(id)) return { id, name: employees.get(id) };
  if (ALLOW_UNKNOWN_IDS || employees.size === 0) return { id, name: "" };
  return null;
}

/* ---------- auth ---------- */
function sign(payload) { const b = Buffer.from(JSON.stringify(payload)).toString("base64url"); const s = crypto.createHmac("sha256", TOKEN_SECRET).update(b).digest("base64url"); return b + "." + s; }
function verify(tok) {
  if (!tok) return null; const [b, s] = tok.split("."); if (!b || !s) return null;
  const exp = crypto.createHmac("sha256", TOKEN_SECRET).update(b).digest("base64url");
  if (s.length !== exp.length || !crypto.timingSafeEqual(Buffer.from(s), Buffer.from(exp))) return null;
  try { const p = JSON.parse(Buffer.from(b, "base64url").toString()); return p.exp > Date.now() ? p : null; } catch { return null; }
}
const failed = new Map();
function rateOk(ip) { const f = failed.get(ip); if (!f) return true; if (Date.now() - f.t > 15 * 60e3) { failed.delete(ip); return true; } return f.n < 10; }
function rateFail(ip) { const f = failed.get(ip) || { n: 0, t: Date.now() }; f.n++; failed.set(ip, f); }

/* ---------- helpers ---------- */
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".png": "image/png", ".svg": "image/svg+xml", ".ico": "image/x-icon", ".json": "application/json" };
function send(res, code, body, type = "application/json; charset=utf-8", extra = {}) {
  const data = typeof body === "string" || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  res.writeHead(code, { "Content-Type": type, "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "Referrer-Policy": "same-origin", ...extra });
  res.end(data);
}
function readBody(req, limit = MAX_BODY) {
  return new Promise((ok, bad) => {
    let n = 0; const chunks = [];
    req.on("data", c => { n += c.length; if (n > limit) { bad(Object.assign(new Error("too large"), { code: 413 })); req.destroy(); } else chunks.push(c); });
    req.on("end", () => ok(Buffer.concat(chunks).toString("utf8")));
    req.on("error", bad);
  });
}
async function json(req) { const t = await readBody(req); try { return JSON.parse(t || "{}"); } catch { throw Object.assign(new Error("bad json"), { code: 400 }); } }
const str = (v, n) => String(v ?? "").slice(0, n);
const num = v => Number.isFinite(+v) ? +v : 0;
function sanitizeRun(r) {
  const runId = str(r.runId, 40).replace(/[^A-Za-z0-9]/g, "");
  if (runId.length < 8) return null;
  const members = Array.isArray(r.members) ? r.members.map(cleanId).filter(Boolean).slice(0, 8) : [];
  return {
    schema: num(r.schema), runId, mode: r.mode === "group" ? "group" : "solo",
    name: str(r.name, 60), employeeId: cleanId(r.employeeId), members,
    startedAt: num(r.startedAt) || null, completedAt: num(r.completedAt) || null, updatedAt: Date.now(),
    status: ["registered", "in_progress", "completed"].includes(r.status) ? r.status : "in_progress",
    progressPct: num(r.progressPct), points: num(r.points), cyberScore: num(r.cyberScore), level: str(r.level, 40), levelN: num(r.levelN),
    stagesCleared: Array.isArray(r.stagesCleared) ? r.stagesCleared.map(num).slice(0, 10) : [],
    finalPct: r.finalPct === null || r.finalPct === undefined ? null : num(r.finalPct), finalRank: r.finalRank ? str(r.finalRank, 40) : null,
    badges: Array.isArray(r.badges) ? r.badges.map(b => str(b, 20)).slice(0, 40) : [],
    mods: r.mods && typeof r.mods === "object" ? r.mods : {},
    qs: r.qs && typeof r.qs === "object" ? r.qs : {},
    tracks: r.tracks && typeof r.tracks === "object" ? { day: str(r.tracks.day, 10) || null, ai: str(r.tracks.ai, 10) || null } : {},
    history: Array.isArray(r.history) ? r.history.slice(-80).map(h => ({ at: num(h.at), ev: str(h.ev, 120), pts: num(h.pts), lvl: str(h.lvl, 40) })) : [],
    device: str(r.device, 60), bonus: 0, title: null,
    prizePoints: num(r.prizePoints), badgesN: num(r.badgesN), firstCorrect: num(r.firstCorrect), firstAnswered: num(r.firstAnswered),
    activeMs: Math.max(0, num(r.activeMs)), practice: !!r.practice,
    finalized: !!r.finalized, finalizedAt: num(r.finalizedAt) || null, spinPts: num(r.spinPts), timeUp: !!r.timeUp
  };
}
function boardRows() {
  return Object.values(runs).filter(r => r.name && (r.points || 0) > 0)
    .map(r => ({ runId: r.runId, name: r.mode === "group" ? r.name : (r.name || r.employeeId).split(/\s+/)[0], pts: (r.prizePoints || r.points || 0) + (r.bonus || 0), level: r.level, group: r.mode === "group", title: r.title || null, at: r.startedAt || 0 }))
    .sort((a, b) => b.pts - a.pts || a.at - b.at).slice(0, 10).map(({ runId, ...x }) => x);
}

/* ---------- prize ranking (same rules as the dashboard) ---------- */
const STAGE_COUNT = 5;
const TIERS = [
  { key: "champ", name: "Champion", cum: 3, pts: 1200, badges: 11, final: 90 },
  { key: "plat", name: "Platinum", cum: 20, pts: 1200, badges: 11, final: 90 },
  { key: "gold", name: "Gold", cum: 50, pts: 1075, badges: 9, final: 80 },
  { key: "silver", name: "Silver", cum: 100, pts: 875, badges: 7, final: 70 }
];
const meets = (t, r) => r.prizePts >= t.pts && r.badgesN >= t.badges && (r.finalPct || 0) >= t.final;
function prizeRank() {
  const first = {};
  Object.values(runs).forEach(r0 => {
    const r = { ...r0, prizePts: r0.prizePoints || r0.points || 0, badgesN: r0.badgesN || (r0.badges || []).length, activeMs: r0.activeMs || 0 };
    if (r.mode === "group" || r.practice || !(r.timeUp || r.finalized || (r.finalPct !== null && r.finalPct !== undefined))) return;
    const k = r.employeeId || r.runId, p = first[k];
    if (!p || (r.startedAt || 9e15) < (p.startedAt || 9e15)) first[k] = r;
  });
  const list = Object.values(first).sort((a, b) => b.prizePts - a.prizePts || (b.finalPct || 0) - (a.finalPct || 0) || b.badgesN - a.badgesN || (a.activeMs || 9e15) - (b.activeMs || 9e15) || (a.completedAt || 9e15) - (b.completedAt || 9e15));
  let used = 0;
  list.forEach((r, i) => {
    r.rank = i + 1; r.tier = null; if (used >= 100) return;
    if (used < 3 && r.finalPct !== null && r.finalPct !== undefined) { r.tier = TIERS[0]; used++; return; }
    for (const t of TIERS.slice(1)) if (meets(t, r) && used < t.cum) { r.tier = t; used++; return; }
  });
  const ti = r => r.tier ? TIERS.indexOf(r.tier) : 9;
  list.forEach((r, i) => r._o = i); list.sort((a, b) => ti(a) - ti(b) || a._o - b._o); list.forEach((r, i) => r.rank = i + 1);
  return list;
}

/* ---------- routes ---------- */
async function api(req, res, url) {
  const p = url.pathname, m = req.method, ip = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "").split(",")[0].trim();
  const admin = verify((req.headers.authorization || "").replace(/^Bearer\s+/i, ""));

  if (p === "/api/health") return send(res, 200, { ok: true, org: ORG_NAME, checkIds: employees.size > 0 && !ALLOW_UNKNOWN_IDS });

  if (p === "/api/login" && m === "POST") {
    const b = await json(req); const ids = (Array.isArray(b.ids) ? b.ids : [b.employeeId]).slice(0, 8);
    const found = {}, missing = [];
    for (const id of ids) { const e = lookup(id); if (e) found[e.id] = e.name; else missing.push(cleanId(id) || String(id || "")); }
    return send(res, missing.length ? 404 : 200, { ok: !missing.length, found, missing });
  }

  if (p === "/api/runs" && m === "POST") {
    const r = sanitizeRun(await json(req)); if (!r) return send(res, 400, { error: "bad run" });
    const ids = r.mode === "group" ? r.members : [r.employeeId];
    if (!ids.length || ids.some(id => !lookup(id))) return send(res, 403, { error: "unknown employee" });
    const prev = runs[r.runId]; if (prev) { r.bonus = prev.bonus || 0; r.title = prev.title || null; r.rewardAt = prev.rewardAt; r.startedAt = prev.startedAt || r.startedAt; }
    runs[r.runId] = r; scheduleSave(); return send(res, 200, { ok: true });
  }

  const rw = p.match(/^\/api\/runs\/([A-Za-z0-9]{8,40})\/reward$/);
  if (rw && m === "POST") {
    const r = runs[rw[1]]; if (!r) return send(res, 404, { error: "not found" });
    const b = await json(req); if (r.rewardAt) return send(res, 409, { error: "already rewarded" });
    r.bonus = (r.bonus || 0) + Math.max(0, Math.min(100, num(b.pts))); if (b.title) r.title = str(b.title, 30);
    r.history = (r.history || []).concat({ at: Date.now(), ev: b.title ? `Wheel title: ${str(b.title, 30)}` : `Wheel bonus +${num(b.pts)}`, pts: (r.points || 0) + r.bonus, lvl: r.level });
    r.rewardAt = Date.now(); scheduleSave(); return send(res, 200, { ok: true });
  }

  if (p === "/api/leaderboard") return send(res, 200, { rows: boardRows() });

  const rk = p.match(/^\/api\/rank\/([A-Za-z0-9]{8,40})$/);
  if (rk && m === "GET") {
    const me = runs[rk[1]]; if (!me) return send(res, 200, { reason: "not saved yet" });
    if (me.practice) return send(res, 200, { reason: "practice run" });
    if (me.mode === "group") return send(res, 200, { reason: "team entry" });
    const list = prizeRank(), mine = list.find(r => r.runId === me.runId);
    if (!mine) { const other = list.find(r => r.employeeId === me.employeeId); return send(res, 200, { reason: other ? "an earlier run counts" : "keep playing to get ranked", total: list.length }); }
    return send(res, 200, { rank: mine.rank, total: list.length, tier: mine.tier ? mine.tier.name : null });
  }

  if (p === "/api/admin/login" && m === "POST") {
    if (!ADMIN_PASSWORD) return send(res, 503, { error: "ADMIN_PASSWORD is not configured on the server" });
    if (!rateOk(ip)) return send(res, 429, { error: "Too many attempts — wait 15 minutes" });
    const b = await json(req); const pw = typeof b.password === "string" ? b.password : "";
    const ok = pw.length === ADMIN_PASSWORD.length && crypto.timingSafeEqual(Buffer.from(pw), Buffer.from(ADMIN_PASSWORD));
    if (!ok) { rateFail(ip); return send(res, 401, { error: "Wrong password" }); }
    return send(res, 200, { token: sign({ role: "admin", exp: Date.now() + 12 * 3600e3 }) });
  }
  if (p.startsWith("/api/admin/")) {
    if (!admin) return send(res, 401, { error: "login required" });
    if (p === "/api/admin/runs" && m === "GET") return send(res, 200, { rows: Object.values(runs).map(r => ({ ...r, points: (r.points || 0) + (r.bonus || 0) })), employees: employees.size, at: Date.now() });
    if (p === "/api/admin/employees" && m === "POST") {
      const text = await readBody(req, 5 * 1024 * 1024); const map = loadEmployees(text);
      if (!map.size) return send(res, 400, { error: "No employee IDs found. Use a CSV with columns: EmployeeID,Name" });
      employees = map; await fsp.writeFile(EMP_FILE, text); return send(res, 200, { ok: true, count: map.size });
    }
    if (p === "/api/admin/runs" && m === "DELETE") { runs = {}; scheduleSave(); return send(res, 200, { ok: true }); }
    const dm = p.match(/^\/api\/admin\/runs\/([A-Za-z0-9]{8,40})$/);
    if (dm && m === "DELETE") { if (!runs[dm[1]]) return send(res, 404, { error: "not found" }); delete runs[dm[1]]; scheduleSave(); return send(res, 200, { ok: true }); }
    return send(res, 404, { error: "not found" });
  }
  return send(res, 404, { error: "not found" });
}

async function serveStatic(req, res, url) {
  let rel = decodeURIComponent(url.pathname); if (rel === "/" || rel === "") rel = "/index.html";
  const root = path.resolve(PUBLIC_DIR), file = path.resolve(path.join(root, rel));
  if (!file.startsWith(root)) return send(res, 403, "Forbidden", "text/plain");
  try {
    const data = await fsp.readFile(file);
    send(res, 200, data, MIME[path.extname(file)] || "application/octet-stream", { "Cache-Control": rel === "/index.html" ? "no-cache" : "public, max-age=3600" });
  } catch {
    const data = await fsp.readFile(path.join(root, "index.html")); send(res, 200, data, MIME[".html"], { "Cache-Control": "no-cache" });
  }
}

http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://localhost");
  try {
    if (url.pathname.startsWith("/api/")) await api(req, res, url);
    else await serveStatic(req, res, url);
  } catch (e) { if (!res.headersSent) send(res, e.code && e.code >= 400 && e.code < 600 ? e.code : 500, { error: e.message || "error" }); }
}).listen(PORT, () => console.log(`[ready] ${ORG_NAME} Cyber Challenge on :${PORT} — ${Object.keys(runs).length} runs stored`));
